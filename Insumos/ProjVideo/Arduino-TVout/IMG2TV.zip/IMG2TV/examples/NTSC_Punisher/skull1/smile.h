#include <avr/pgmspace.h>
#ifndef smile_H
#define smile_H
extern const unsigned char smile[];
#endif
