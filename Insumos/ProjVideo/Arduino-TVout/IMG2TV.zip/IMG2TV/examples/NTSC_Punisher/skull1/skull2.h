#include <avr/pgmspace.h>
#ifndef SKULL2_H
#define SKULL2_H

extern const unsigned char skull2[];
#endif
