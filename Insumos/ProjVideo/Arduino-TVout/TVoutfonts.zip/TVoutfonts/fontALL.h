#ifndef FONTALL_H
#define FONTALL_H

#include "font4x6.h"
#include "font6x8.h"
#include "font8x8.h"
#include "font8x8ext.h"

#endif