Reconstructed source of Eastern Hosue Software CW Moser ASSM/TED MAco Assembler and Text Edit MAE for the KIM-1

Based upon original binary dumnped in 1980 by Hans Otten to tape, converted to binary in 2004.

Binary Original CW MOSER assmted.BIN runs on the KIM-1 and KIM-1 Simulator
Load at $2000, start at $2000

The KIM-1 Simulator has on the console window a rightclick menu, choose Add LF to CR.

The source is typed in, starting with the disassembly and the CWMOSER.TXT and Fast Cassete source file as comment source.
The resulting binary is exactly identical to the tape dump.
